import React from "react"

const SignUp = () =>{
  
  return(
    <div>
      Sign Up
    </div>
  )
}

export default SignUp;